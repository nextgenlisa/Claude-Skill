# Credits and attribution

This page lists who built what in the Google Maps Scraper Kit, and the licenses of the parts it uses.

The kit, its Google Maps engine (`engine/`), the scripts, the skill and the slash commands are designed
and built by Mahan ([@Mahanaicoach](https://github.com/Mahanaicoach)), MIT licensed (see [LICENSE](LICENSE)).

## History: gosom/google-maps-scraper

Kit versions 1.x ran [gosom/google-maps-scraper](https://github.com/gosom/google-maps-scraper) by
Georgios Komninos ([@gosom](https://github.com/gosom)), an MIT-licensed Go scraper, as its official
Docker image, unmodified. That engine shaped this kit: the job API (`/api/v1/jobs`, the job body, the
`Status` values) and the 36 CSV column names, with the JSON layout inside them, are its design, kept
so that scripts and files made for kit 1.x keep working (what changed inside a few columns: SETUP.md,
"Upgrading from kit 1.x"). Kit 2.0's own engine contains none of its code, so this repository no longer
carries its license notice. To support its author, star the repository:
https://github.com/gosom/google-maps-scraper

## Chrome for Testing

On a machine with no Chrome, Chromium, Edge or Brave, `scripts/engine.py start` downloads Google's
[Chrome for Testing](https://googlechromelabs.github.io/chrome-for-testing/) headless shell, pinned by
version and SHA-256 in `engine/browser.py`. It is Google's build of Chrome, made from the open-source
Chromium project. This repository does not contain or redistribute it: it comes from Google's servers
straight into `.engine/` on your machine, under Google's terms for Chrome (its `ABOUT` file) and the
open-source licenses listed in its `LICENSE.headless_shell` file. The Docker image installs Debian's
`chromium` package instead, under Chromium's BSD-style license and the notices Debian ships with it.

## City list: GeoNames

The web UI's Where box offers only real places: about 168,000 cities and towns of more than 1,000
people (name, region, country, coordinates), from the [GeoNames](https://www.geonames.org/)
`cities1000` dump, licensed under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).
`engine/presets/cities.tsv.gz` is that data, cut to those five fields, one row per city label.

The What box offers a hand-picked list of popular business types for this kit
(`engine/presets/business-types.json`), then Google's business category names (4,053, US English)
from [lobstrio/google-business-categories](https://github.com/lobstrio/google-business-categories)
by lobstr.io. Your browser loads that list from GitHub at runtime, pinned to one commit in
`engine/serve.py`, and caches it for 30 days. This repository does not contain or redistribute it,
because that repository has no license file. Until the browser has fetched it once, the box offers the kit's own list only.

## Website signals adapted from OpenLeadFinder

The `--tech` detection patterns, the intent score and the obfuscated-email patterns in
`scripts/scrape.py`, and its private-address guard, are adapted from OpenLeadFinder, Mahan's
self-hosted lead finder. It is released under the MIT License, Copyright (c) 2026 OpenLeadFinder
contributors, with the license text below.

## MIT License text (OpenLeadFinder)

```
MIT License

Copyright (c) 2026 OpenLeadFinder contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## Optional website rendering: Playwright

The optional website enrichment fallback uses [Microsoft Playwright for Python](https://github.com/microsoft/playwright-python),
licensed under [Apache License 2.0](https://github.com/microsoft/playwright-python/blob/main/LICENSE).
It is installed separately through `requirements-browser.txt`; this repository does not vendor its code
or browser binaries. The default HTTP crawl and Maps engine do not require Playwright.
